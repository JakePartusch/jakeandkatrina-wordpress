<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
?>
<div class="mk-product-loop compact-layout grid--float">
	<section class="products mk--row js-el" data-grid-config='{"item":".product"}' data-mk-component="Grid">