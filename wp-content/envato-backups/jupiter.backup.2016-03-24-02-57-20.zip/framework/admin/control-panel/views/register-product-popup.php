<div class="cp-warning-box clearfix">
	<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="64px" height="64px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
		<circle fill="#F95C32" cx="8" cy="8" r="8"/>
		<rect x="7.1" y="3" fill="#FFFFFF" width="1.9" height="6.3"/>
		<circle fill="#FFFFFF" cx="8" cy="12.3" r="1.2"/>
	</svg>

	<div class="warning-message">
		<?php echo $view_params['message']; ?>
	</div>
</div>