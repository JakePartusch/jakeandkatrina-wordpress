<div class="callout">
    <span class="item-title"><?php _e('More Add-ons', 'mk_framework'); ?></span>
    <span class="item-desc"><?php _e('Download more awesome add-ons to move your website to the next level', 'mk_framework'); ?></span>
    <a class="cp-button medium green" href="https://artbees.net/themes/template/" target="_blank">
    <i class="ic-download"></i>
    <span><?php _e('Download Now', 'mk_framework'); ?></span>
    </a>
</div>